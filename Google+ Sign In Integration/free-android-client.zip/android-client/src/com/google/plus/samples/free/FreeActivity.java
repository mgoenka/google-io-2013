/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.plus.samples.free;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.app.ActionBar.Tab;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.plus.PlusClient;
import com.google.android.gms.plus.model.people.Person;
import com.google.gson.reflect.TypeToken;

import com.google.plus.samples.free.plus.PlusClientFragment;
import com.google.plus.samples.free.plus.PlusClientFragment.OnSignInListener;
import com.google.plus.samples.free.tasks.JsonTask;
import com.google.plus.samples.free.tasks.JsonTaskLoader;
import com.google.plus.samples.free.tasks.JsonTask.FetchCallback;

/**
 * Manages the authentication using Google sign-in and the Free back end
 * service across all activities.
 * 
 * Authentication using Google sign-in is delegated to
 * {@link PlusClientFragment} which responds via the
 * {@link #onSignedIn(PlusClient)} method to indicated successful authentication
 * and the {@link #onSignInFailed()} method to indicate failure.
 * 
 * On successful authentication the corresponding OAuth token is passed to the
 * Free back end service to be associated with a service specific profile.
 */
public class FreeActivity extends SherlockFragmentActivity implements
		OnSignInListener, View.OnClickListener, 
		LoaderManager.LoaderCallbacks<List<User>> {

	/**
	 * Code used to identify the login request to the {@link PlusClientFragment}
	 * .
	 */
	public static final int REQUEST_CODE_PLUS_CLIENT_FRAGMENT = 0;

	/** Delegate responsible for handling Google sign-in. */
	protected PlusClientFragment mPlus;

	/** Used to retrieve the Free back end session id. */
	private AsyncTask<Object, Void, User> mAuthTask;

	/** Client used to access the Free API. */
	protected ApiClient mApiClient;

	/** Person as returned by Google Play Services. */
	protected Person mPlusPerson;

	/** Profile as returned by the Free service. */
	protected User mFreeUser;
	
	/**
	 * Stores the {@link com.google.android.gms.common.SignInButton} for use in
	 * the action bar.
	 */
	protected SignInButton mSignInButton;

    // For Profile fragment
	private ProfileFragment mProfileFragment;        
	
    // For Friends fragment 
    private FriendViewFragment mFriendFragment;
    private LoaderManager mLoaderMgr;
    private JsonTaskLoader<List<User>> mFriendsLoader;
    private Timer mTimer;
    
	// For tracking tab state
    private Boolean isFriends = false;
    private Boolean isProfile = true;
    
    
    //
    // Part I Getting the user signed-in and retrieving profile data.
    //
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		ActionBar bar = getSupportActionBar();
		bar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
		ActionBar.Tab profileTab = bar.newTab();
		ActionBar.Tab friendTab = bar.newTab();
				
		profileTab.setText("Profile");
		profileTab.setTabListener(new TabListener(this));
		bar.addTab(profileTab);;		
		
		friendTab.setTabListener(new TabListener(this));
		friendTab.setText("Friends");		
		bar.addTab(friendTab);		
        	
		enableProfileFragment();
		
		/*
		mApiClient = new ApiClient();

		// Create the PlusClientFragment which will initiate authentication if
		// required.
		// AuthUtil.SCOPES describe the permissions that we are requesting of
		// the user to access their information and write to their moments vault.
		// AuthUtil.VISIBLE_ACTIVITIES describe the types of moment which we can
		// read from or write to the user's vault.		
		mPlus = PlusClientFragment.getPlusClientFragment(this, ApiClient.SCOPES,
				ApiClient.VISIBLE_ACTIVITIES);

		mSignInButton = (SignInButton) getLayoutInflater().inflate(
				R.layout.sign_in_button, null);
		
		mSignInButton.setOnClickListener(this);
								
		// For profile UI
        updateFreeButton();
       
        // For friends UI        
        mLoaderMgr = getSupportLoaderManager();
        mFriendsLoader = 
        		(JsonTaskLoader<List<User>>)mLoaderMgr.initLoader(0, null, this);
                
		*/				
	}	
	
	@Override
	public void onActivityResult(int requestCode, int responseCode,
			Intent intent) {
		super.onActivityResult(requestCode, responseCode, intent);

		// Delegate onActivityResult handling to PlusClientFragment to resolve
		// authentication failures, eg. if the user must select an account or 
		// grant our application permission to access the information we have 
		// requested in AuthUtil.SCOPES and AuthUtil.VISIBLE_ACTIVITIES
		mPlus.handleOnActivityResult(requestCode, responseCode, intent);
	}
	
	/**
	 * Click handler for the View that triggers sign-in.
	 * @param view The View object containing click data.
	 */
	@Override
	public void onClick(View view) {
		/*
		if (view.getId() == R.id.sign_in_button) {
			mPlus.signIn(REQUEST_CODE_PLUS_CLIENT_FRAGMENT);
		}
		*/
	}	

	/**
	 * Invoked when the {@link PlusClientFragment} delegate has failed to
	 * authenticate the user. Failure to authenticate will often mean that the
	 * user has not yet chosen to sign in.
	 * 
	 * The default implementation resets the Free profile to null.
	 */
	@Override
	public void onSignInFailed() {
		supportInvalidateOptionsMenu();
	}
	
	/**
	 * Provides a guard to ensure that a user is authenticated.
	 */
	protected boolean requireSignIn() {
		/*
		if (!mPlus.isAuthenticated()) {
			mPlus.signIn(REQUEST_CODE_PLUS_CLIENT_FRAGMENT);
			return false;
		} else {
			return true;
		}		
		*/
		return false;
	}
	
	/**
	 * Invoked when the {@link PlusClientFragment} delegate has successfully
	 * authenticated the user.
	 * 
	 * @param plusClient
	 *            The connected PlusClient which gives us access to the Google+
	 *            APIs.
	 */
	@Override
	public void onSignedIn(PlusClient plusClient) {
		/*
		if (plusClient.isConnected()) {
			mPlusPerson = plusClient.getCurrentPerson();

			// Retrieve the account name of the user which allows us to retrieve
			// the OAuth access token that we securely pass over to the Free 
			// service to identify and authenticate our user there.
			final String name = plusClient.getAccountName();

			// Asynchronously authenticate with the Free service and
			// retrieve the associated Free profile for the user.
			mAuthTask = new AsyncTask<Object, Void, User>() {
				@Override
				protected User doInBackground(Object... o) {
					return ApiClient.authenticate(FreeActivity.this, name);
				}

				@Override
				protected void onPostExecute(User result) {
					if (result != null) {
						setAuthenticatedProfile(result);
					} else {
						signOut();
					}
				}
			};

			mAuthTask.execute();
		}
		*/
	}

	/**
	 * Invoked when the Free profile has been successfully retrieved for an
	 * authenticated user.
	 * 
	 * @param profile
	 */
	public void setAuthenticatedProfile(User profile) {
		/*
		mFreeUser = profile;
		
		supportInvalidateOptionsMenu();
		
        // For profile
        updateFreeButton();
        updateProfile();             
        */
        		
		
        // For friends
        /*
		mTimer.schedule(new TimerTask() {
            @Override
            public void run() {
            	mFriendsLoader.forceLoad();		
            }
        }, 0, 15000);
		*/
	}


	// Free button provided as example.
	
	/**
	 * Method used to reverse the current user's "Free" status. This function
	 * makes an API call to the /free endpoint and sets it to the opposite of
	 * the user's current status.
	 */
	public void toggleFree(){
		if (isAuthenticated()){
			mApiClient.free(!mFreeUser.free, 
					new JsonTask.FetchCallback<Void>() {
	            @Override
	            public void onError(Void v) {
	                // Rollback on failure
	                mFreeUser.free = !mFreeUser.free;
	                updateFreeButton();
	            }
	        });
			
			mFreeUser.free = !mFreeUser.free;
			updateFreeButton();
		}
	}
	

	/**
	 * Updates the UI for profile data such as photo on the profile fragment.
	 */
	public void updateProfile() {
	  if (mProfileFragment != null && mProfileFragment.getActivity() != null
	  && mFreeUser != null && mFreeUser.free != null){
	    mProfileFragment.updateProfile(isAuthenticated(), mFreeUser.googleDisplayName, 
	        mFreeUser.googlePublicProfilePhotoUrl);
	  }
	}   

	/**
	 * Updates the UI for the "free" button on the profile fragment.
	 */
    public void updateFreeButton() {    	
    	if (mProfileFragment != null && mProfileFragment.getActivity() != null
      && mFreeUser != null && mFreeUser.free != null){
    		mProfileFragment.updateFreeButton(isAuthenticated(), mFreeUser.free);
    	}    	
	}

	//
	// Part II: Sign out and disconnect
	//

	
	/**
	 * Clears the user profile and signs the user out from Google+ to allow
	 * the user to switch accounts.
	 */
	protected void signOut() {
		/*
		ApiClient.invalidateSession();
		setAuthenticatedProfile(null);
		mPlusPerson = null;
		mPlus.signOut();
		*/
	}	
	
	//
	// UI Code 
	//
	

    //
    // Part III Listing friends statuses
    //
    
    /**
     * Creates a Loader for retrieving the user's friends.
     * @param id The ID whose loader is to be created.
     * @param bundle Extra arguments passed to the Loader.
     * @return An object for asynchronous loading.
     */
	@Override
	public Loader<List<User>> onCreateLoader(int id, Bundle bundle) {
		/*
        return new JsonTaskLoader<List<User>>(
        		this, 
        		ApiClient.USER_FRIENDS_LIST, 
        		new TypeToken<ArrayList<User>>() {}.getType(),
        		true);
       	*/
		// Remove the following line after you uncomment the previous block.
		return null;
	}
    
	/**
	 * Handler for when the loader resets.
	 * 
	 * @param loader The User list asynchronous Loader.
	 */
	@Override
	public void onLoaderReset(Loader<List<User>> loader) {
		/*
		if (mFriendFragment == null || mFriendFragment.mFriends == null){
        	return;
        }
		mFriendFragment.mFriends.clear();
		*/
	}
	
	/**
	 * Handler for when the friends are returned from the API query.
	 * 
	 * @param loader The asynchronous loader containing the result data.
	 * @param friends The current user's visible people returned as User 
	 * objects.
	 */
	@Override
	public void onLoadFinished(Loader<List<User>> loader, List<User> friends) {
        /*
		if (mFriendFragment == null || mFriendFragment.mFriends == null){
        	return;
        }
		mFriendFragment.mFriends.clear();

        if (friends != null) {
        	for (int i=0; i < friends.size(); i++){
        		friends.get(i).googlePublicProfilePhotoUrl = 
        				friends.get(i).googlePublicProfilePhotoUrl.
        				replace("sz=50","sz=300");        
        	}
        	mFriendFragment.mFriends.addAll(friends);
        }       

        if (mFriendFragment.mFriendListAdapter != null){
        	mFriendFragment.mFriendListAdapter.notifyDataSetChanged();
        }
        
    	updateProfile();
		updateFreeButton();
		*/
	}   


    /**
     * Initializes and shows the profile fragment.
     */
	private void enableProfileFragment(){
        FragmentManager fragmentManager = getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = 
				fragmentManager.beginTransaction();
		
		mProfileFragment = new ProfileFragment();
				
		fragmentTransaction.add(R.id.fragment_container, mProfileFragment);
		fragmentTransaction.commit();
	}	
	
	/**
	 * A tab listener handler for tabulated fragment switching.
	 */
	private class TabListener implements ActionBar.TabListener
	{
	    
	    public TabListener(FragmentActivity activity) {
	    	// TODO Auto-generated method stub
	    }
	    
		@Override
		public void onTabSelected(Tab tab, FragmentTransaction ft) {		

			if(tab.getPosition() == 0 && !isProfile)
			{			
				isFriends = false;
		        FragmentManager fragmentManager = getSupportFragmentManager();
				FragmentTransaction fragmentTransaction = 
						fragmentManager.beginTransaction();
				
				
				mProfileFragment = new ProfileFragment();				
				fragmentTransaction.replace(R.id.fragment_container, mProfileFragment);													
				fragmentTransaction.commit();
				
				if (mFriendsLoader != null){
					mFriendsLoader.forceLoad();
				}
				isProfile = true;
			}			
			else if (tab.getPosition() != 0 && !isFriends)
			{
				isProfile = false;
		        FragmentManager fragmentManager = getSupportFragmentManager();						        
		        
		        FragmentTransaction fragmentTransaction = 
						fragmentManager.beginTransaction();
								       
		        mFriendFragment = new FriendViewFragment();		        		        
		        fragmentTransaction.replace(R.id.fragment_container, mFriendFragment);		        
				fragmentTransaction.commit();
				
				if (mFriendsLoader != null){
					mFriendsLoader.forceLoad();
				}
				isFriends = true;
			}
		}

		@Override
		public void onTabUnselected(Tab tab, FragmentTransaction ft) {
			// TODO Auto-generated method stub
		}
		@Override
		public void onTabReselected(Tab tab, FragmentTransaction ft) {
			// TODO Auto-generated method stub
		}
	}	
	
	
	/**
	 * Configures the menu items to contain Sign-out, Refresh, and so on.
	 * @param menu The menu to configure.
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);

		getSupportActionBar().setDisplayShowCustomEnabled(false);

		if (isAuthenticated()) {
			// Show the 'sign out' menu item only if we have an authenticated
			// Free profile.
			menu.add(0, R.id.menu_item_sign_out, 0,
					getString(R.string.sign_out_menu_title)).setShowAsAction(
					MenuItem.SHOW_AS_ACTION_NEVER);

			menu.add(0, R.id.menu_item_disconnect, 0,
					getString(R.string.disconnect_menu_title)).setShowAsAction(
					MenuItem.SHOW_AS_ACTION_NEVER);
		} else if (!isAuthenticated() && !isAuthenticating() && 
				!(mSignInButton == null)) {
			ActionBar.LayoutParams params = new ActionBar.LayoutParams(
					ActionBar.LayoutParams.WRAP_CONTENT,
					ActionBar.LayoutParams.WRAP_CONTENT, Gravity.RIGHT);
			getSupportActionBar().setCustomView(mSignInButton, params);
			getSupportActionBar().setDisplayShowCustomEnabled(true);
		}

		return true;
	}

	/**
	 * Handler for when options, created in onCreateOptions, are selected.
	 * @param item The state of the selected menu.
	 */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		
     
        case R.id.menu_item_refresh:
            mFriendsLoader.forceLoad();
            return true;
		
		case R.id.menu_item_disconnect:
			mApiClient.disconnectAccount(new FetchCallback<Void>() {
				@Override
				public void onSuccess(Void result) {
					signOut();
				}

				@Override
				public void onError(Void result) {
					Toast toast = Toast.makeText(FreeActivity.this,
							getString(R.string.disconnect_failed),
							Toast.LENGTH_LONG);
					toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
					toast.show();
				}
			});

			return true;

		case R.id.menu_item_sign_out:
			signOut();
			return true;
		}

		return super.onOptionsItemSelected(item);
	}
	
	//
	// Timers
	//
    
    /**
     * Timer starter for a timer user on Friends operations.  
     */
	@Override
	public void onStart() {
		super.onStart();
		
		mTimer = new Timer();
	}
	
	/**
	 * Timer stop code for timer used for Friends operations.
	 */
	@Override
	public void onStop() {
		super.onStop();

		// Reset any asynchronous tasks we have running.
		resetTaskState();
	
		mTimer.cancel();
	}

	/**
	 * Resets the state of asynchronous tasks used by this activity.
	 */
	protected void resetTaskState() {
		if (mAuthTask != null) {
			mAuthTask.cancel(true);
			mAuthTask = null;
		}
	}
	
	//
	// Utility functions
	//
	
	/**
	 * @return true if the user is currently authenticated through Google
	 *         sign-in and the the user's Free profile has being fetched.
	 */
	public boolean isAuthenticated() {
		if (mPlus == null){
			return false;
		}
		return mPlus.isAuthenticated() && mFreeUser != null;
	}

	/**
	 * @return true if the user is currently being authenticated through Google
	 *         sign-in or if the the user's Free profile is being fetched.
	 */
	public boolean isAuthenticating() {
		if (mPlus == null){
			return false;
		}
		return mPlus.isConnecting() || mPlus.isAuthenticated()
				&& mFreeUser == null;
	}

}
