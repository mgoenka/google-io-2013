/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.plus.samples.free.plus;

import android.content.Intent;
import android.net.Uri;

/**
 * Helpers to generate Intents used in the Free app.
 */
public class IntentUtils {
    
    /**
     * Create an {@link android.content.Intent} to display a Google+ user's profile in the Google+
     * app.
     * 
     * @param profileUrl Google+ profile URL of the user.
     * @return the {@link android.content.Intent} to invoke.
     */
    public static Intent getPlusUserIntent(String profileUrl) {
        return new Intent(Intent.ACTION_VIEW, Uri.parse(profileUrl));
    }

}
