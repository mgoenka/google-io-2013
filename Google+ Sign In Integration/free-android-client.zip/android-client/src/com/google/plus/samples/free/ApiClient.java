/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.plus.samples.free;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import org.apache.http.HttpResponse;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.google.android.gms.auth.GoogleAuthException;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.common.Scopes;
import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.google.plus.samples.free.tasks.JsonTask;
import com.google.plus.samples.free.tasks.JsonTask.FetchCallback;

/**
 * API interface for interacting with the Free backend.
 */
public class ApiClient {
    
    private static final String TAG = ApiClient.class.getSimpleName();

    public static final String[] SCOPES = {
            Scopes.PLUS_LOGIN
    };

    public static final String[] VISIBLE_ACTIVITIES = {
            "http://schemas.google.com/AddActivity"
    };
    
    /** The UserAgent string supplied with all Free HTTP requests. */
    public static final String USER_AGENT = "Free Agent";

    /** The protocol and hostname used to access the Free service. */
    public static final String API_HOST;

    /** The URL root used to access the Free API. */
    public static final String API_ROOT;
    
    /** The API URL used to retrieve the friends for a user. */
    public static final String USER_FRIENDS_LIST;

    /** The API URL used to set free status. */
    public static final String FREE;

   /** The API URL used to connect to the Free service. */
    public static final String API_CONNECT;

    /** The API URL used to disconnect from the Free service. */
    public static final String API_DISCONNECT;

    public static final String ME_ID = "me";
    
    private static final String SCOPE_STRING = "oauth2:" + TextUtils.join(" ", SCOPES);

    private static final String ACCESS_TOKEN_JSON = "{ \"access_token\":\"%s\"}";
    
    private static final String FREE_JSON = "{ \"free\": %s }";
    
    /** Buffer size used to read HTTP responses. */
    public static final int IO_BUFFER_SIZE = 4 * 1024;

    /** 
     * Maximum total size of HTTP response that will be read.  
     * Larger responses will be considered an error.
     */
    public static final int MAX_READ_SIZE = 64 * 1024 * 1024; // 64 MiB

    private static String sAccessToken = null;

    private static String sCookies = null;

    
    //
    // Part I Authorization
    // 
    
    public static User authenticate(Context ctx, String account) {
    	/*
        HttpURLConnection urlConnection = null;
        OutputStream outStream = null;
        String response = null;
        int statusCode = 0;

        try {
            URL url = new URL(API_CONNECT);

            sAccessToken = GoogleAuthUtil.getToken(ctx, account, SCOPE_STRING);
            
            Log.v(TAG, "Authenticating at [" + url + "] with: " + sAccessToken);
            
            byte[] postBody = String.format(ACCESS_TOKEN_JSON, sAccessToken).getBytes();

            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setAllowUserInteraction(false);
            urlConnection.setDoOutput(true);
            urlConnection.setRequestProperty("User-Agent", USER_AGENT);
            urlConnection.setRequestProperty("Content-Type", "application/json");

            outStream = urlConnection.getOutputStream();
            outStream.write(postBody);

            statusCode = urlConnection.getResponseCode();
            
            if (statusCode == 200) {
                User result = null;
                String[] cookies = urlConnection.getHeaderField("set-cookie").split(";");
                for (String cookie : cookies) {
                    if (cookie.trim().startsWith("JSESSIONID")) {
                        InputStream responseStream = urlConnection.getInputStream();
                        byte[] responseBytes = getContent(responseStream).toByteArray();
                        response = new String(responseBytes, "UTF-8");
                        
                        if (!TextUtils.isEmpty(response)) {
                            result = new Gson().fromJson(response, User.class);
                        }
                        
                        sCookies = cookie;
                        break;
                    }
                }
                
                Log.v(TAG, "Authenticated: " + response);
                result.googlePublicProfilePhotoUrl = 
                		result.googlePublicProfilePhotoUrl.replace("sz=50", "sz=300");
                return result;
            } else { 
                response = getErrorResponse(urlConnection);
                
                Log.w(TAG, "HTTP Status (" + statusCode + ") while authenticating: " + response);
                GoogleAuthUtil.invalidateToken(ctx, sAccessToken);
                return null;
            }
        } catch (MalformedURLException e) {
            Log.e(TAG, e.getMessage(), e);
        } catch (IOException e) {
            Log.e(TAG, e.getMessage(), e);
        } catch (GoogleAuthException e) {
            GoogleAuthUtil.invalidateToken(ctx, sAccessToken);
        } catch (JsonParseException jsonException) {
            Log.e(TAG, "Unable to parse the json response from: " + API_CONNECT,
                    jsonException);
            Log.e(TAG, "Response was: " + response);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            
            if (outStream != null) {
                try {
                    outStream.close();
                } catch (IOException e) {
                    Log.e(TAG, e.getMessage(), e);
                }
            }
        }
		*/
        return null;
    }
    
    //
    // Free status is provided
    // 
    
    /**
     * Performs the API query to the /api/free endpoint for setting the state 
     * for the current user.
     */
    public void free(final Boolean free, final FetchCallback<Void> callback) {
    	try {
    		final byte[] body = String.format(FREE_JSON, free.toString()).getBytes("UTF-8");

			JsonTask<Void> task = new JsonTask<Void>(FREE, callback, Void.class) {
				{
					mRequestMethod = "PUT";
					mRequestBody = body;
				}
			};

			task.execute();
		} catch (IOException e) {
    		Log.e(TAG, "Failed to convert JSON string", e);
    	}
    }       
    
    // 
    // Disconnect
    //
    
    /**
     * Method used to disconnect the current users account from Google.  We make a call to the
     * Free service rather than calling PlusClient.revokeAndDisconnect() locally to ensure
     * that the client and server stay in sync.
     * 
     * @param callback The callback used to deliver the result.
     */
    public void disconnectAccount(final FetchCallback<Void> callback) {
    	/*
        JsonTask<Void> task = new JsonTask<Void>(API_DISCONNECT, callback, Void.class) {
            { mRequestMethod = "POST"; }
        };
        task.execute();
        */
    }
    

    public static void invalidateSession() {
        /*
    	sAccessToken = null;
        sCookies = null;
        */
    }
    
    
    //
    // Utilities
    //
    
    /**
     * Read the content of an InputStream.
     * 
     * @param inputStream the InputStream to be read.
     * @return the content of the InputStream as a ByteArrayOutputStream.
     * @throws IOException if the content size exceeds {@link #MAX_READ_SIZE} bytes.
     */
    public static ByteArrayOutputStream getContent(InputStream inputStream) throws IOException {
        ByteArrayOutputStream content = new ByteArrayOutputStream();

        // Read the response into a buffered stream
        int totalBytes = 0;
        int readBytes = 0;
        byte[] buffer = new byte[IO_BUFFER_SIZE];
        while ((readBytes = inputStream.read(buffer)) != -1) {
            if (totalBytes > MAX_READ_SIZE) {
                throw new IOException("Data download too large.");
            }

            content.write(buffer, 0, readBytes);
            totalBytes += readBytes;
        }

        return content;
    }

    
    /** 
     * Read the content of an HttpResponse.
     * 
     * @param response the HttpResponse to be read.
     * @return the content of the HttpResponse as a ByteArrayOutputStream.
     * @throws IOException if the content size exceeds {@link #MAX_READ_SIZE} bytes.
     */
    public static ByteArrayOutputStream getContent(HttpResponse response) throws IOException {
        return getContent(response.getEntity().getContent());
    }
    
    /**
     * Gets an error given a URL.
     * @param urlConnection Contains the error extracted.
     * @return The error.
     */
    public static String getErrorResponse(HttpURLConnection urlConnection) {
        InputStream errorStream = urlConnection.getErrorStream();
        
        try {
            if (errorStream != null) {
                byte[] responseBytes = getContent(errorStream).toByteArray();
                return new String(responseBytes, "UTF-8");
            }
        } catch (IOException e) {
            return "Failed to get error response: " + e.getLocalizedMessage();
        }
        
        return null;
    }
    
    /**
     * Sets authorization data for the session shared with the server.
     * @param connection The connection used for API calls.
     */
    public static void setAuthHeaders(HttpURLConnection connection) {
        Log.d(TAG, "Authorization: OAuth " + sAccessToken);
        Log.d(TAG, "Session: " + sCookies);
        connection.setRequestProperty("Authorization", "OAuth " + sAccessToken);
        connection.setRequestProperty("Cookie", sCookies);
    }
    
    
    public static boolean hasSession() {
    	return sCookies != null;
    }
    
    //
    // Configuration of API endpoints
    //
    
    static {
        Properties config = new Properties();
        String apiHost = null;
        
        try {
            config.load(ApiClient.class.getClassLoader().getResourceAsStream("config.properties"));
 
            apiHost = config.getProperty("api_host");
        } catch (Exception e) {
            Log.e(TAG, "Failed to load configuration properties file", e);
        } finally {
            API_HOST = apiHost;
            
            if (API_HOST != null) {
                API_ROOT = API_HOST + "/api";
                
                API_CONNECT = API_ROOT + "/connect";
                API_DISCONNECT = API_ROOT + "/disconnect";
                USER_FRIENDS_LIST = API_ROOT + "/friends";
                FREE = API_ROOT + "/free";
            } else {
                API_ROOT = null;
                
                API_CONNECT = null;
                API_DISCONNECT = null;
                USER_FRIENDS_LIST = null;
                FREE = null;
            }
        }
    }
}
