package com.google.plus.samples.free;

import com.actionbarsherlock.app.SherlockFragment;
import com.google.android.imageloader.ImageLoader;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ProfileFragment extends SherlockFragment implements OnClickListener{
    private LinearLayout mFreeLayout;
    Button mFreeButton;
    private ImageView mProfileImage;
    private TextView mProfileText;
    
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
		
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.profile_fragment, container, false);
        
        mFreeLayout = (LinearLayout)view.findViewById(R.id.frag_free_button_layout);
        mFreeButton = (Button)view.findViewById(R.id.frag_free_button);
        mFreeButton.setOnClickListener(this);
        
        mProfileImage = (ImageView)view.findViewById(R.id.frag_profile_photo);
        mProfileText = (TextView)view.findViewById(R.id.frag_profile_text);
               
        return view;
    }		

	public void updateProfile(Boolean isAuth, String displayName, 
			String photoUrl){
	
		if (isAuth){
			mProfileText.setText(displayName);
			
			if (!TextUtils.isEmpty(photoUrl)) {
				ImageLoader imageLoader = ((FreeApp)this.getActivity().
						getApplication()).getImageLoader();
				imageLoader.bind(mProfileImage, photoUrl, null);
			}
			
			mProfileImage.setVisibility(View.VISIBLE);
			mProfileText.setVisibility(View.VISIBLE);	
		} else {
			mProfileImage.setVisibility(View.INVISIBLE);
			mProfileText.setVisibility(View.INVISIBLE);			
		}	
	}
	
	public void onClick(View view){
		
		FreeActivity profileActivity = (FreeActivity)getActivity();		
		profileActivity.toggleFree();
		
	}
	
    public void updateFreeButton(Boolean isAuth, Boolean free) {
      if (isAuth){
    	mFreeLayout.setVisibility(View.VISIBLE);
      	if (free) {
  			mFreeButton.setBackgroundResource(R.drawable.green_button);
  			mFreeButton.setText("Free");
  		} else {
  			mFreeButton.setBackgroundResource(R.drawable.red_button);
  			mFreeButton.setText("Busy");
  		}
      }else{
    	  mFreeLayout.setVisibility(View.INVISIBLE);
      }    	
	}
	
}