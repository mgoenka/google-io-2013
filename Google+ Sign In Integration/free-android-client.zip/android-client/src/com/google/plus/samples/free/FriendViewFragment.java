package com.google.plus.samples.free;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;


import com.actionbarsherlock.app.SherlockFragment;

public class FriendViewFragment extends SherlockFragment {

    public List<User> mFriends = new ArrayList<User>(0);
    public FriendListAdapter mFriendListAdapter;
    public ListView mFriendListView;
    
	
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
		
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.friends_fragment, container, false);

        mFriendListAdapter = new FriendListAdapter(this.getActivity(), mFriends);
        mFriendListView = (ListView)view.findViewById(R.id.frag_friends_view);
        mFriendListView.setAdapter(mFriendListAdapter);        
        
        return view;
    }
	
}
